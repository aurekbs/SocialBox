package application;

public class Intersections {
	public native void runAllPairs(String graph_filename, String solution_filename);
	public native void runBentleyOttmann(String graph_filename, String solution_filename);
}